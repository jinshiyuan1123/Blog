<?php
header("Content-type:text/html; charset=utf-8");
include_once("cmsconfig.php");
include_once("class/c_db.php");
include_once("class/c_other.php");
include_once("class/c_runtime.php");
include_once("class/c_page.php");
include_once("class/c_md5.php");

if(sqlguolv()==1){die('禁止输入特殊符号和非法访问！');}

$mb=$themepath."search.mb";
$cache=$searchpath."index.html";

$p="/%27|%22|\+|%2B|%3b|%7e|%60|%40|%23|%24|%5e|%2b|%3c|%3e|%7b|%7d|%5b|%5d|\'|<|>|\*/i";
#$_SERVER['QUERY_STRING']=preg_replace($p,'',$_SERVER['QUERY_STRING']);
#$_GET=preg_replace($p,'',$_GET);
$_POST=preg_replace($p,'',$_POST);
$_POST=str_replace('\\','',$_POST);
$word=$_POST['word'];
#echo $word;
#die();

if(preg_match($p,$word==1)){die('严禁输入非法字符和符号！<a href="javascript:history.back()">请返回</a>');}
if($word==''){index();}else{so();}


function index(){
global $word,$mb,$cache;
ob_start();
include($mb);
$html = ob_get_contents ();
ob_clean();
$html=mbreplace($html);
echo $html;
}

function so(){
global $word,$mb,$cache,$setsearchsecond,$setsearchtimes;
#检测是否恶意搜索
$fromip = $_SERVER["REMOTE_ADDR"];
session_start();
$_SESSION['search_chk']='';
if($_SESSION['search_error']==''){$_SESSION['search_error']=0;}
if($_SESSION['search_starttime']==''){$_SESSION['search_starttime']=time();}
if($_SESSION['search_error'] > $setsearchtimes){$_SESSION['search_chk']="<p style='color:red;'>您的搜索太过用力！请关闭浏览器再试试。</p>";$_GET['word']=='';}
elseif(time()-$_SESSION['search_time']<$setsearchsecond){$_SESSION['search_chk']="<p style='color:red;'>严禁短时间内多次搜索！请".$setsearchsecond."秒后重试</p>";$_GET['word']=='';}

ob_start();
include($mb);
$html = ob_get_contents ();
ob_clean();
$html=mbreplace($html);
echo $html;
}


function searchlist(){
global $tabhead,$word;
$tab=$tabhead."arts";
mysql_select_db($tab);
#ifword
if($word==''){echo'<p>请输入搜索词</p>';}elseif($_SESSION['search_chk']!=''){echo $_SESSION['search_chk'];}
else{
	$_SESSION['search_error'] = $_SESSION['search_error']+1;
$_SESSION['search_time'] =time();
$chk=" where title like '%".$word."%'";
$sql = mysql_query("select * from ".$tab.$chk);
$_SESSION["count"]=0;
if(!$sql){echo "(数据库查询失败!)<br>";exit;}
#row begin
else{
while($row=mysql_fetch_array($sql)){
$_SESSION["count"]=$_SESSION["count"]+1;
$p_id=$row['id'];
$p_author=$row['author'];
$p_title=$row['title'];
$p_info=$row['content'];
$p_info=getartinfo($p_info);
$p_arturl=arttourl($row['htmlname']);
$p_htmlname=$row['htmlname'];
$p_date=$row['edate'];
$p_hit=$row['hit']+1;

$p_tags='';
$a=artidgettagids($p_id);
$shu=count($a);
    for($i=1;$i<=$shu;$i++){
    $tagid=$a[$i-1];
    $b=navidgetnav($tagid);
    $type=$b['type'];
    $name=$b['name'];
 $htmlname=$b['htmlname'];
    if($type=='nav'){$p_nav=$name;$p_navurl=tagtourl($htmlname);}
    if($type=='tag'){$p_tags=$p_tags.'<a href="'.tagtourl($htmlname).'" >'.$name.'</a>,';}
    }

	
echo <<<EOF
<p style='margin-bottom:10px;'><a target=_blank href='{$p_arturl}'>{$p_title}</a>&nbsp; &nbsp; &nbsp;被围观了{$p_hit} 次
<br>{$p_date}&nbsp; &nbsp; &nbsp;tags: {$p_tags}
</p>
EOF;
}
}#row end
if($_SESSION["count"]==0){echo"<p style='color:red;'>很抱歉，没有找到符合您条件的搜索结果，请再次尝试输入一些不同的关键字进行搜索。</p>";}
}#ifword end
}



?>