<?php require_once('all.php');chkadcookie();require_once('../class/pinyin.php');global $date;?>
<!DOCTYPE html><html>  <head>
    <meta charset="utf-8">
	<?php
    switch ($g)    { 
    case "edit":echo"<meta name=referrer content=never >";break;     }	
?>
    <title>后台管理</title>
    <link rel="stylesheet" type="text/css" href="css/right.css"> 
		<script type="text/javascript" src="jquery-1.8.2.min.js"></script>
			<script>
jQuery(function($){ 
//全选 
	$("#chooseall").click(function(){ 
	$("input[name='checkbox']").attr("checked","true"); 
	}) 
	//取消全选 
	$("#unchooseall").click(function(){ 
	$("input[name='checkbox']").removeAttr("checked"); 
	}) 

	$("#delchoose").click(function(){ 
	var aa=""; 
	$("input[name='checkbox']:checkbox:checked").each(function(){ aa=aa+$(this).val()+',' }) 
	if(aa==''){alert("请选择要操作的文章！");}
			else{if(confirm('确定[删除]选中项吗?')){
				htmlobj=$.ajax({url:"ajax.php?g=delchooseart&ids="+aa,async:false});
				$("#jieguo").html(htmlobj.responseText);
			arr = aa.split(",");
			shu=arr.length-1;
			$("input[name='checkbox']").removeAttr("checked"); 
					for (var i=0;i<shu;i++)
					{
					$("#list"+arr[i].replace(',','')).hide();
					$("#artshu").html($("#artshu").text()-1);
					}
					setTimeout('$("#jieguo").html("");',1500);
			}}
			
	}) 
	

	$("#delchoosssse").click(function(){ 
	var aa=""; 
	$("input[name='checkbox']:checkbox:checked").each(function(){ aa=aa+$(this).val()+',' }) 
	if(aa==''){alert("请选择要操作的文章！");}
		else{if(confirm('确定[删除]选中项吗?')){htmlobj=$.ajax({url:"ajax.php?g=delchooseart&ids="+aa,async:false});$("#jieguo").html(htmlobj.responseText);$("#list"+aa.replace(',','')).html(''); 
		arr = aa.split(",");
		alert
		}}
	}) 
	
	$("#gotopchoose").click(function(){ 
	var aa=""; 
	$("input[name='checkbox']:checkbox:checked").each(function(){ aa=aa+$(this).val()+',' }) 
	if(aa==''){alert("请选择要操作的文章！");}
		else{if(confirm('确定[置顶]选中项吗?')){htmlobj=$.ajax({url:"ajax.php?g=gotopchooseart&ids="+aa,async:false});$("#jieguo").html(htmlobj.responseText);setTimeout('location.href="?";',1000); }}
		$("input[name='checkbox']").removeAttr("checked"); 
	}) 
	
		$("#untopchoose").click(function(){ 
	var aa=""; 
	$("input[name='checkbox']:checkbox:checked").each(function(){ aa=aa+$(this).val()+',' }) 
	if(aa==''){alert("请选择要操作的文章！");}
		else{if(confirm('确定[取消置顶]选中项吗?')){htmlobj=$.ajax({url:"ajax.php?g=untopchooseart&ids="+aa,async:false});$("#jieguo").html(htmlobj.responseText);setTimeout('location.href="?";',1000); }}
		$("input[name='checkbox']").removeAttr("checked"); 
	}) 
	
}) 

function jsgotop(id){
	var topid=id;
	topid="top"+topid.replace(/,/, "");
	htmlobj=$.ajax({url:"ajax.php?g=gotopchooseart&ids="+id,async:false});
	$("#jieguo").html(htmlobj.responseText);
	$("#"+topid).html("[已置顶]");
	$("#img"+topid).html("<img onclick=jsuntop('"+id+"') title=将文章置顶/取消置顶 src=images/rocket.png >");
	setTimeout('$("#jieguo").html("");',1500);
}

function jsuntop(id){
	var topid=id;
	topid="top"+topid.replace(/,/, "");
	htmlobj=$.ajax({url:"ajax.php?g=untopchooseart&ids="+id,async:false});
	$("#jieguo").html(htmlobj.responseText);
	$("#"+topid).html("");
		$("#img"+topid).html("<img onclick=jsgotop('"+id+"') title=将文章置顶/取消置顶 src=images/rocket.png >");
		setTimeout('$("#jieguo").html("");',1500);
}

function changepic(){
frm.pic.value='<?=$weburl?>images/'+frm.pics.value;
  document.getElementById('spanpic').innerHTML='<img src='+frm.pic.value+' ><iframe src="'+frm.pic.value+' frameBorder=0 scrolling=no width=0 ></iframe>';
}
function changepic2(){
  var x=document.getElementById("pics");
  x.options[x.selectedIndex].text="自定义图片";
  document.getElementById('spanpic').innerHTML='<img src='+frm.pic.value+' ><iframe src="'+frm.pic.value+' frameBorder=0 scrolling=no width=0 ></iframe>';
}

</script>
<?php
@$g=$_GET["g"];
if($g=='addart'|$g=='edit'){
?>
	<script src="jspost.js"></script> 
	<link rel="stylesheet" href="../ke4/themes/default/default.css" />
	<link rel="stylesheet" href="../ke4/plugins/code/prettify.css" />
	<script charset="utf-8" src="../ke4/kindeditor.js"></script>
	<script charset="utf-8" src="../ke4/lang/zh_CN.js"></script>
	<script charset="utf-8" src="../ke4/plugins/code/prettify.js"></script>
	<script type="text/javascript">
	function formatImg(html){  
            var newContent= html.replace(/<img[^>]*>/gi,function(match,capture){ 
			var match = match.replace(/ data-src=\"(.*?)\" /gi,'  ');
			match=match.replace(/&amp;tp=webp&amp;wxfrom=5&amp;wx_lazy=1/g,"");
			match=match.replace(/&tp=webp&wxfrom=5&wx_lazy=1/g,"");
var res = match.match(/ src=\"(.*?)\" /gi);		  
  match = '<img  src='+res[0]+' style="max-width:600px" >';
 
			  return match; 
        });  
        return newContent;  
    }  
	
		function formatImg2(html){  
            var newContent= html.replace(/<img[^>]*>/gi,function(match,capture){  
var match = match.replace(/ class=\"(.*?)\" /gi,'  ');
			  match = match.replace(/ data-src=\"(.*?)\" /gi,'  '); 
match = match.replace(/ style=\"(.*?)\" /gi,'  '); 			  
			  match = match.replace(/ data-ratio=\"(.*?)\" /gi,'  '); 
			  match = match.replace(/ data-type=\"(.*?)\" /gi,'  ');
			  match = match.replace(/ data-w=\"(.*?)\" /gi,'  ');
			  match = match.replace(/ data-width=\"(.*?)\" /gi,'  ');	
			  match = match.replace(/ _width=\"(.*?)\" /gi,'  ');	
			  match = match.replace(/ data-fail=\"(.*?)\" /gi,'  ');					  
			  match = match.replace(/ style=\"(.*?)\" /gi,'  '); 
 match = match.replace(/ data-copyright=\"(.*?)\" /gi,'  ');
 match = match.replace(/ data-order=\"(.*?)\" /gi,'  '); 
 match = match.replace(/ data-s=\"(.*?)\" /gi,'  ');  
			  return match; 
        });  
        return newContent;  
    }  
	
var editor;
		KindEditor.ready(function(K) {
			editor = K.create('textarea[name="content"]', {
				cssPath : '../ke4/plugins/code/prettify.css',
				uploadJson :  '../ke4/php/upload_json.php',
				filterMode: false,//是否开启过滤模式
				fileManagerJson : '../ke4/php/file_manager_json.php',
				allowFileManager : true,
				afterCreate : function() {
					var self = this;
					K.ctrl(document, 13, function(){
					chk();
					});
					K.ctrl(self.edit.doc, 13, function() {
					chk();
					});
					K('a[name=clearhtmlexceptimg]').click(function(e) {
					var aa=editor.text();
aa=aa.replace(/<img/g,"<br><img");	
aa=aa.replace(/\n\n/g,"\n");
aa=aa.replace(/\r\n\r\n/g,"\r\n");
aa=aa.replace(/						/g,"");
aa=aa.replace(/					/g,"");
aa=aa.replace(/				/g,"");
aa=aa.replace(/			/g,"");
aa=aa.replace(/	/g,"");
aa=aa.replace(/\n/g,"<br>\n");
aa=aa.replace(/<br>\n<br>\n/g,"");
aa=aa.replace(/ <br>/g," ");
aa=formatImg(aa);

					editor.html(aa);
					});
				}
			});
			prettyPrint();
		});

	function chk(){
	addtag(document.getElementById('tags2').value);
	if(frm.title.value==''){alert("请填写文章标题！");frm.title.focus();return false;}
	else if(frm.title.value=='在此键入标题'){alert("请填写文章标题！");frm.title.focus();return false;}
	else if(editor.html()==''){alert("请填写文章内容！");editor.focus();return false;}
	else if(frm.tags.value==''){alert("请至少填写一个tag！");frm.tags2.focus();return false;}
	else if(frm.author.value==''){alert("请填写作者信息！");frm.author.focus();return false;}
	else{editor.sync();frm.submit();}	
					}
					
function savedraft(){
	if(frm.title.value==''){$("#jieguo").html("<div id=appmsg>请输入标题</div>");setTimeout('$("#jieguo").html("");',1500);frm.title.focus();return false;}
	else if(frm.title.value=='在此键入标题'){$("#jieguo").html("<div id=appmsg>请输入标题</div>");setTimeout('$("#jieguo").html("");',1500);frm.title.focus();return false;}
	else if(editor.html()==''){$("#jieguo").html("<div id=appmsg>请输入内容</div>");setTimeout('$("#jieguo").html("");',1500);editor.focus();return false;}
	editor.sync();
var cont = $("input,select,textarea").serialize();
$.ajax({
	url:'ajax.php?g=savedraft',type:'post',dataType:'json',data:cont,
	success:function(data){
		 var str = data.jieguo;
     $("#jieguo").html(str);
	 frm.id.value=data.id;
						}
});

setTimeout('$("#jieguo").html("");',3000); 
}


var secs = 60; //自动保存草稿倒计时 
function daojishi() {
	for(var i=1;i<=secs;i++) {  window.setTimeout("update(" + i + ")", i * 1000);} 
}	

function update(num) { 
jishi=secs-num;
document.getElementById("daojishi").innerText=jishi+"秒后自动保存草稿";
    if(num == secs) {savedraft();daojishi();} 
} 
daojishi();

	</script>
<?php
}
?>
</head>
<body> 
<?php
    switch ($g)
    {
    case "addart":addart();break; 
    case "addsave":addsave();break; 
    case "del":del();break; 
    case "edit":edit();break; 
    case "editsave":editsave();break; 
    case "delall":delall();break; 
    case "chkall":chkall();break; 
    default:artlist();break; 
    }	
?>




<?php 
function artlist(){
?>
<?php
global $tabhead;
$tab=$tabhead."arts";
$chk="";
mysql_select_db($tab);
$sql = mysql_query("select * from ".$tab.$chk."");
$artshu=mysql_num_rows($sql);
$options = array(
	'total_rows' => $artshu, //总行数
	'list_rows'  => '10',  //每页显示量
);
$page = new page($options);

    switch ($_GET["s"])
    {
	case "dateasc":$sql =  mysql_query("select * from ".$tab.$chk." order by edate asc limit $page->first_row , $page->list_rows");break; 
	case "datedesc":$sql =  mysql_query("select * from ".$tab.$chk." order by edate desc limit $page->first_row , $page->list_rows");break; 
	case "idasc":$sql =  mysql_query("select * from ".$tab.$chk." order by id asc limit $page->first_row , $page->list_rows");break; 
	case "iddesc":$sql =  mysql_query("select * from ".$tab.$chk." order by id desc limit $page->first_row , $page->list_rows");break; 
    case "top":$sql =  mysql_query("select * from ".$tab.$chk." order by top desc limit $page->first_row , $page->list_rows");break; 
    default:$sql =  mysql_query("select * from ".$tab.$chk." order by edate desc limit $page->first_row , $page->list_rows");break; 
    }	
?>
<div id=rightmenu>
<div id=rightmenu_top><ul><li><b>您的位置：<a href="art.php">文章列表</a> < <a href="right.php">后台首页</a></b></li></ul></div>
<ul>
<span id="jieguo"></span>
<div id=artlist>
<ul id=top>
<li id=ico>id <a href="?s=idasc" title="按ID递增排序" >↑</a> <a href="?s=iddesc" title="按ID递减排序" >↓</a></li>
<li id=set1>操作 </li>
<li id=name>标题 <a href="?s=top"  title="按已置顶排序" >已置顶</a></li>
<li id=tags>tags标签</li>
<li id=author>作者</li>
<li id=date>修改日期 <a href="?s=dateasc"  title="按修改日期递增排序" >↑</a> <a href="?s=datedesc" title="按修改日期递减排序" >↓</a></li>
</ul>
 
<?php
global $artpath;
if(!$sql){echo "<font color=red>(打开数据库时遇到错误!)</font>";return false;}
while($row=mysql_fetch_array($sql))
{
$p_id=$row['id'];
$p_type=$row['type'];
$p_author=$row['author'];
$p_title=mb_substr($row['title'],0,20,'utf-8');
$p_htmlname=$row['htmlname'];
$p_arturl=arttourl($p_htmlname);
$p_date=$row['edate'];
$p_top=$row['top'];
$chktop='';
$chktop2='jsgotop';
if($p_top=='yes'){$chktop='[已置顶]';$chktop2='jsuntop';};
$chkhtml='id=grayimg';
if(file_exists('../'.$artpath.$p_htmlname)){$chkhtml='';}
$p_nav='';
$p_tag='';
$chktype='';
$a=artidgettagids($p_id);
$shu=count($a);
    for($i=1;$i<=$shu;$i++){
    $navid=$a[$i-1];
    $b=navidgetnav($navid);
    $navtype=$b['type'];
    $navname=$b['name'];
    if($navtype=='tag'){$p_tag=$p_tag.$navname.',';}
    if($navtype=='nav'){$p_nav=$navname;}
    }
if($p_type=='draft'){$chktype="[草稿] ";$p_tag=$row['tags'];}
echo <<<EOF
<ul id=list{$p_id} >
<li id=ico>{$p_id}</li>
<li id=set>
<input type="checkbox" name="checkbox" value='{$p_id}'>
<a id=imgtop{$p_id} ><img onclick="{$chktop2}('{$p_id},')" title="将文章置顶/取消置顶" src="images/rocket.png"></a>
<a href='{$p_arturl}' target=_blank><img title=预览html页面 src="images/ie.png"></a>
<a href='?g=edit&id={$p_id}'><img title=编辑修改 src="images/edit.png"></a>
<a href='html.php?g=haart&p={$p_htmlname}'><img {$chkhtml}  title=生成html页面 src="images/build.png"></a>
<a onclick="if(confirm('确定 [删除] 吗?')){location.href='?g=del&id={$p_id}';}"><img  title=删除 src="images/delete.png"></a>
</li>
<li id=name><a href='?g=edit&id={$p_id}' title=编辑修改 >{$chktype}<span id=top{$p_id} >{$chktop}</span>{$p_title}</a></li>
<li id=tags>{$p_tag}</li>
<li id=author>{$p_author}</li>
<li id=date>{$p_date}</li>
</ul>
EOF;
}
?>
<div id=artlist_shu>
<div id=page> 文章数量：<span id=artshu><?=$artshu?></span>篇 
     <?=$page->show(1)?>
</div>
</div>
</div>
<br>
<span id="artlist_btn">
<a  id=btn_blue  onclick="location.href='art.php?g=addart';">发布内容</a>
<a  id=chooseall  >全选</a>
<a  id=unchooseall  >取消全选</a>
<a  id=delchoose  onclick="delchoose()">删除</a>
<a  id=gotopchoose >置顶</a>
<a  id=untopchoose >取消置顶</a>
<a  id=btn_yellow onclick="if(confirm('确定删除所有吗?')){location.href='?g=delall';}">删除所有</a>
<a  id=btn_blue href="?g=chkall">修复错误</a>
</span>
<br><br>
</ul></div>
</body></html>
<?php 
}
?>


<?php 
function addart(){
$_SESSION['jdate']='';$_SESSION['jid']='';
global $webauthor,$date,$weburl;
global $tabhead;
$title=$_GET['title'];
$content=$_GET['content'];
?>
<?php script()?>
<div id=rightmenu>
<div id=rightmenu_top><ul><li><b>您的位置：发布内容 < <a href="art.php">文章列表</a> < <a href="right.php">后台首页</a></b></li></ul></div>
<ul>
<div id=addart_left>
<form id="frm" name="frm" method="post" action="?g=addsave" onSubmit="return false;" >
<span id="jieguo"></span>
<?php
if($title==''){$title='在此键入标题';}
?>
<p><input type=hidden size=10 name=id id=id ><input  style="width:400px"  type=text name=title id=title_txt value="<?=$title?>" onfocus="if(this.value=='在此键入标题'){this.value=''}" onblur="if(this.value==''){this.value='在此键入标题'}">文章标题，严禁特殊符号</p>
<p><input  style="width:400px"  name=htmlname type=text value="默认自动转为拼音" onfocus="if(this.value=='默认自动转为拼音'){this.value=''}" onblur="if(this.value==''){this.value='默认自动转为拼音'}">html别名，静态目录，严禁特殊符号</p>
<p ><input  style="width:400px;"  type=text name=pic id=pic value="<?=$weburl?>images/pic1.jpg" title="您可在这里直接输入缩略图网址如http://www.axublog.com/logo.jpg" onchange="changepic2()" >填写缩略图网址 
</p>
<p><textarea id="content" name="content" style="width:670px;height:380px;visibility:hidden;"><?=$content?></textarea></p>
</div>
<!------------left---------------->
<div id=addart_right>
<p>选择缩略图<select onchange="changepic()" id=pics name=pics title="您可自定义网站根目录images下pic1.jpg-pic10.jpg"></p>
<?
for($i=1;$i<=10;$i++){
	if (file_exists("../images/pic".$i.".jpg"))  
    {echo"<option>pic".$i.".jpg</option>";}  
	else{echo"<option>不存在pic".$i.".jpg</option>";}  
}
?>
</select>
<div style="text-align:center" title=缩略图 >
<span id=spanpic ><img src="<?=$weburl?>images/pic1.jpg" ></span><br>
</div>
<input type=hidden size=20 name=oldtags id=oldtags type=text value="<?=$tags?>" >
<input  type=hidden size=20 name=tags id=tags type=text value="<?=$tags?>" >
 <div>已加入tags：<div id=js_showtags><?=@$p_tag?></div></div>
<input size=18 name=tags2 id=tags2 type=text >
  <a id=btn_green onclick="addtag(document.getElementById('tags2').value);">添加</a><br>
 多个标签请用英文逗号,分开<br>
<p><a onclick="showhidediv('hidetagsdiv')">[从常用标签中选择：]</a></p>
<p id=hidetagsdiv>
<?php
$a=getalltag();
$shu=count($a);
for($i=1;$i<=$shu;$i++){
$b=$a[$i-1];
$id=$b['id'];
$name=$b['name'];
echo '<a title="加入此标签" onclick="addtag(\''.$name.'\');">'.$name.'</a>  ';
}
?>
</p>
<p>日期：<?=$date?><input size=20 name=date type=hidden value="<?=$date?>" ></p>
<p>作者：<input size=12 name=author type=text value="<?=$webauthor?>" ></p>
<div id=addart_left_savebtn><a onclick="chk()">发布内容 快捷键:Ctrl+Enter</a>
<hr><a id=daojishi onclick="savedraft()">保存草稿</a><hr>
<a name="clearhtmlexceptimg">去除html(保留图片)</a>
<hr><p id=msg></p>
</div>
</div>
</form>
<!------------right---------------->
</ul></div></body></html>
<?php 
}
?>


<?php 
function addsave(){
	if($_SESSION['jid']!=''){editsave();exit();}
global $tabhead,$webname,$webinfo,$weburl,$webauthor,$themepath,$artpath,$tagpath,$title;
$title=$_POST['title'];
if(strlen($title)>70){$title=substr($title,0,70);}

$htmlname=$_POST['htmlname'];if($htmlname==''){$htmlname=$_SESSION['htmlname'];}
$htmlname=htmlnameguolv($htmlname);
if($htmlname=='默认自动转为拼音'|$htmlname==''){$htmlname=pinyin($title);}
$content=$_POST['content'];
#$content=gethttpimg($content);
$date=$_POST['date'];if($date==''){$date=$_SESSION['date'];}
$author=htmlnameguolv($_POST['author']);if($author==''){$author=$_SESSION['author'];}
$tags=$_POST['tags'];if($tags==''){$tags=$_SESSION['tags'];}
$tags=htmlnameguolv($tags);
$pic=$_POST['pic'];

if (!get_magic_quotes_gpc()) {
$pic=addslashes($pic);
$title=addslashes($title);
$content=addslashes($content);
$htmlname=addslashes($htmlname);
$author=addslashes($author);
$tags=addslashes($tags);
}
#$content=httptomyurl($content);
if(strlen($content)<5){die('内容为空');}
if($title==''){die('标题为空');}
$tab=$tabhead."arts";
mysql_select_db($tab);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>后台管理</title>
    <link rel="stylesheet" type="text/css" href="css/right.css">
  </head>
  <body> 
<div id=rightmenu>
<div id=rightmenu_top><ul><li><b>您的位置：发布内容 < <a href="art.php">文章列表</a> < <a href="right.php">后台首页</a></b></li></ul></div>
<ul>

<?
$chk=" where htmlname='".$htmlname."'";
$sql = mysql_query("select * from ".$tab.$chk);
if(!$sql){echo "(数据库查询失败!)<br>";}
$num=mysql_num_rows($sql);
    if($num==0){
$sql="INSERT INTO ".$tab." (id,author,title,content,htmlname,type,hit,cdate,edate,tags,pic) VALUES (null,'".$author."','".$title."','".$content."','".$htmlname."','art',1,'".$date."','".$date."','".$tags."','".$pic."')";
if(mysql_query($sql)){echo"<p>发布内容成功</p><br>";
}

else{echo"发布内容 [".$title."] <font color=red>失败1</font><br>".$sql;return;}
$artid = mysql_insert_id();
addtags($tags,$artid);
echo'<iframe src="html.php?g=haart&p='.$htmlname.'" scrolling="no" frameborder="0" height="300" width="600"></iframe>';
    }
    else{echo'html别名已存在！';}
?>
</ul></div></body></html>
<?php 
}
?>


<?php 
function edit(){
$id=$_GET['id'];
$_SESSION['jid']=$id;
if($id==''){echo"<div id=err>文章id为空，请检查！</div>";jump('?',1);}
$a=artidgetart($id);
$author=$a['author'];
$title=$a['title'];
$content=$a['content'];
#$content=stripslashes($content);
#$content=htmlspecialchars($content);
$htmlname=$a['htmlname'];
$type=$a['type'];
$edate=$a['edate'];
$tags2=$a['tags'];
$pic=$a['pic'];
global $date,$weburl;
$edate=$date;
$tags='';
$p_tag='';
$artnavid='';
$a=artidgettagids($id);
$shu=count($a);
    for($i=1;$i<=$shu;$i++){
    $navid=$a[$i-1];
    $b=navidgetnav($navid);
    $navname=$b['name'];
$p_tag=$p_tag.' <li id="tag_'.$navname.'" ><a href="#" onclick="hidetag(\''.$navname.'\');" >'.$navname.'</a></li>';$tags=$tags.$navname.',';
    }
?>

<?php script()?>

<div id=rightmenu>
<div id=rightmenu_top><ul><li><b>您的位置：修改文章<?=$id?> < <a href="art.php">文章列表</a> < <a href="right.php">后台首页</a></b></li></ul></div>

<ul>
<div id=addart_left>
<span id="jieguo"></span>
<form id="frm" name="frm" method="post" action="?g=editsave" >
<input name=id type=hidden value="<?=$id?>" >
<p><input  style="width:400px" type=text name=title value="<?=$title?>" >文章标题，严禁特殊符号</p>
<p><input  style="width:400px"  name=htmlname type=text value="<?=$htmlname?>" >html别名，静态目录，严禁特殊符号</p>
<p ><input  style="width:400px;"  type=text name=pic id=pic_txt value="<?=$pic?>" title="您可在这里直接输入图片地址如http://www.axublog.com/logo.jpg" onchange="changepic2()" >填写缩略图网址 
<!------------<input name=ifdaolianpic id=ifdaolianpic type="checkbox" checked="yes"/>盗链远程图片---------------->
</p>
<?
daolianimght($content);
?>

<p><textarea id="content" name="content" style="width:670px;height:380px;visibility:hidden;"><?=$content;?></textarea></p>
</div>
<!------------left---------------->
<div id=addart_right>
<p>选择缩略图
<select onchange="changepic()" id=pics name=pics title="您可自定义网站根目录images下pic1.jpg-pic10.jpg">
<?
for($i=1;$i<=10;$i++){
	if (file_exists("../images/pic".$i.".jpg"))  
    {echo"<option>pic".$i.".jpg</option>";}  
	else{echo"<option>不存在pic".$i.".jpg</option>";}  
}
?>
</select>
</p>
<div style="text-align:center" title=缩略图 >
<span id=spanpic ><iframe src="<?=$pic?>" frameBorder="0" scrolling="no" width="0"></iframe><img src="<?=$pic?>" ></span><br>
</div>
<input type=hidden size=20 name=oldtags id=oldtags type=text value="<?=$tags?>" >
<input  type=hidden size=20 name=tags id=tags type=text value="<?=$tags?>" >
 <div>已选tags：<div id=js_showtags><?=$p_tag?></div></div>
<input size=18 name=tags2 id=tags2 type=text value="<?=$tags?>" > 
<script>addtag('<?=$tags?>');</script>
<a id=btn_green onclick="addtag(document.getElementById('tags2').value);">添加</a><br>
 多个标签请用英文逗号,分开 <br>
<p><a onclick="showhidediv('hidetagsdiv')">[从常用标签中选择]</a></p>
<p id=hidetagsdiv>
<?php
$a=getalltag();
$shu=count($a);
for($i=1;$i<=$shu;$i++){
$b=$a[$i-1];
$id=$b['id'];
$name=$b['name'];
echo '<a onclick="addtag(\''.$name.'\');">'.$name.'</a>  ';
}
?>
</p>
<p>日期：<?=$edate?><input size=20 name=date type=hidden value="<?=$edate?>" ></p>
<p>作者：<input size=12 name=author type=text value="<?=$author?>" ></p>
<div id=addart_left_savebtn><a onclick="chk()">发布内容 快捷键:Ctrl+Enter</a>
<hr><a id=undaojishi onclick="savedraft()">保存草稿</a>
<hr><a name="clearhtmlexceptimg">去除html(保留图片)</a>
<hr><p id=msg></p>
</div>

</div>
</form>
<!--------------------------->
</ul></div></body></html>
<?php 
}
?>


<?php 
function editsave(){
global $tabhead,$webname,$webinfo,$weburl,$webauthor,$themepath,$artpath,$tagpath,$title;
$id=$_POST['id'];
if($id==''){addsave();exit;}
$title=$_POST['title'];
$htmlname=htmlnameguolv($_POST['htmlname']);
if($htmlname=='默认自动转为拼音'|$htmlname==''){$htmlname=pinyin($title);}
$content=$_POST['content'];
#$content=gethttpimg($content);

$edate=$_POST['date'];
$author=htmlnameguolv($_POST['author']);
$tags=htmlnameguolv($_POST['tags']);
$oldtags=htmlnameguolv($_POST['oldtags']);
$pic=$_POST['pic'];

if (!get_magic_quotes_gpc()) {
$pic=addslashes($pic);
$title=addslashes($title);
$content=addslashes($content);
$htmlname=addslashes($htmlname);
$author=addslashes($author);
$tags=addslashes($tags);
}
#$content=httptomyurl($content);
?>

	<?php script()?>
<div id=rightmenu>
<div id=rightmenu_top><ul><li><b>您的位置：修改文章<?=$id?> < <a href="art.php">文章列表</a> < <a href="right.php">后台首页</a></b></li></ul></div>
<ul>

<?
delarttags($oldtags,$id);
addtags($tags,$id);

$tab=$tabhead."arts";
mysql_select_db($tab);
$sql="UPDATE ".$tab." SET author='".$author."',title='".$title."',type='art',content='".$content."',htmlname='".$htmlname."',edate='".$edate."',tags='".$tags."',pic='".$pic."' where id=".$id;
if(mysql_query($sql)){echo"<p>文章修改成功</p><br>";
echo'<iframe src="html.php?g=haart&p='.$htmlname.'" scrolling="no" frameborder="0" height="300" width="600"></iframe>';
}
else{echo"修改文章<font color=red>失败</font><br>";return;}
?>
</ul></div></body></html>
<?php 
}
?>


<?php 
function del(){
chkoutpost();
$id=$_GET['id'];

global $tabhead;
$tab=$tabhead."arts";

$sql="DELETE FROM ".$tab." WHERE id=".$id;
if(mysql_query($sql)){echo"<div id=ok>文章删除成功</div>";}
else{echo"<div id=err>文章删除失败,请检查分类是否存在，请检查数据库！</div>";jump('javascript:history.back()',1);}

global $tabhead;
$tab=$tabhead."nav_art";
$sql="DELETE FROM ".$tab." WHERE artid=".$id;
if(mysql_query($sql)){echo"<div id=ok>后续处理成功</div>";jump('javascript:history.back()',1);}
else{echo"<div id=err>文章删除失败,请检查数据库！</div>";jump('javascript:history.back()',1);}
}
?>


<?php 
function delall(){
chkoutpost();
global $tabhead;
$tab=$tabhead."arts";
$sql="DELETE FROM ".$tab." WHERE id>0";
if(mysql_query($sql)){echo"<div id=ok>文章删除成功</div>";jump('javascript:history.back()',1);}
else{echo"<div id=err>文章删除失败,请检查数据库！</div>";jump('javascript:history.back()',1);}

global $tabhead;
$tab=$tabhead."nav_art";
$sql="DELETE FROM ".$tab." WHERE artid>0";
if(mysql_query($sql)){echo"<div id=ok>后续处理成功</div>";jump('javascript:history.back()',1);}
else{echo"<div id=err>文章删除失败,请检查数据库！</div>";jump('javascript:history.back()',1);}
}
?>


<?php 
function chkall(){
chkoutpost();

global $tabhead;
$sql = "ALTER TABLE ".$tabhead."arts ADD tags varchar(100) NOT NULL";if (mysql_query($sql)){}
$sql = "ALTER TABLE ".$tabhead."arts ADD pic varchar(255) NOT NULL";if (mysql_query($sql)){}
$sql = "ALTER TABLE ".$tabhead."arts ADD top varchar(10) NOT NULL";if (mysql_query($sql)){}
$sql = "ALTER TABLE ".$tabhead."adusers ADD type varchar(10) NOT NULL";if (mysql_query($sql)){}

$sql = mysql_query("select * from ".$tabhead."arts ");
if(!$sql){echo "<font color=red>(getallart打开数据库时遇到错误!)</font>";return false;}
while($row=mysql_fetch_array($sql))
{
$artids=$artids.'['.$row['id'].']';
}
echo $artids.'<br>';

$tab=$tabhead."nav_art";
$sql = mysql_query("select * from ".$tab." ");
    if(!$sql){echo "<div id=err>(chkall打开数据库时遇到错误!)</div>";return ;}
    while($row=mysql_fetch_array($sql))
    {
        $artid2=$row['artid'];
    $artid='['.$artid2.']';
   if(str_replace($artid,'',$artids)==$artids){$artids2=str_replace($artid2.',','',$artids2).$artid2.',';}
    }

echo $artids2.'<br>';
$a=explode(',',$artids2);
$shu=count($a)-1;
echo '需要处理：'.$shu.'个<br>';
for($i=1;$i<=$shu;$i++){
$sql="DELETE FROM ".$tab." WHERE artid=".$a[$i-1];
if(mysql_query($sql)){echo"<div id=ok>后续处理成功</div>";}
else{echo"<div id=err>后续处理失败,请检查数据库！</div>";}

}
jump('javascript:history.back()',1);
}
?>

<?php
function script(){
echo <<<EOF
<script>
function showhidediv(id){
var sbtitle=document.getElementById(id);
if(sbtitle){
   if(sbtitle.style.display=='block'){
   sbtitle.style.display='none';
   }else{
   sbtitle.style.display='block';
   }
}
}

function choosenavs(str,str2){
if(document.getElementById("nav"+str).checked==true){frm.navs.value=frm.navs.value.replace("["+str+"]","");frm.navs.value=frm.navs.value+"["+str+"]";jspost('ajax.php?g=savesessionnav&q='+str2,'showjspost');}
else{frm.navs.value=frm.navs.value.replace("["+str+"]","");jspost('ajax.php?g=savesessionnav&q=','showjspost');}
}


function chksubmit(){
	addtag(document.getElementById('tags2').value);
	if(frm.title.value==''){alert("请填写文章标题！");frm.title.focus();return false;}
	else if(frm.title.value=='在此键入标题'){alert("请填写文章标题！");frm.title.focus();return false;}
	else if(editor.html()==''){alert("请填写文章内容！");return false;}
	else if(frm.tags.value==''){alert("请至少填写一个tag！");frm.tags.focus();return false;}
	else if(frm.author.value==''){alert("请填写作者信息！");frm.author.focus();return false;}
else{self.sync();frm.submit();}
}

function addnewnav(){
if(addnav.name.value==''){alert("请填写分类名称！");addnav.name.focus();return false;}
jspost('navs.php?g=addsave&name='+addnav.name.value+'&htmlname='+addnav.htmlname.value+'&fuid='+addnav.fuid.value,'showaddnav');
jspost('ajax.php?g=js_getallnav','js_getallnav');
}

function chkhideaddnav2(){
  aa=document.getElementById('addart_hideaddnav2')
if(aa.style.display =="inline"){aa.style.display="none";}
else{aa.style.display="inline";}
}

function hidetag(str){
if(str==''){return;}
var strs= new Array(); //定义一数组
strs=document.getElementById('tags').value.split(","); //字符分割   

instr='';   
instr2='';

for (i=0;i<strs.length-1;i++ )    
    {    
    if(strs[i]!=str){instr=instr+'<li id="tag_'+strs[i]+'" ><a href="#" onclick="hidetag(\''+strs[i]+'\');" >'+strs[i]+'</a></li>';instr2=instr2+strs[i]+',';}
    }
if(strs.length-1==1){instr='';instr2='';}

    js_showtags.innerHTML=instr;
    document.getElementById('tags').value=instr2;
}

function addtag(str){
if(str==''){return;}
str=str+',';
str=str.replace("，，",",");
str=str.replace("，",",");
str=str.replace(",,",",");

document.getElementById('tags2').value='';
var strs= new Array(); //定义一数组
strs=str.split(","); //字符分割      
for (i=0;i<strs.length-1;i++ )    
    {
str=','+document.getElementById('tags').value;
if(str.replace(','+strs[i],'')==','+document.getElementById('tags').value){
js_showtags.innerHTML = js_showtags.innerHTML.replace('<li id="tag_'+strs[i]+'" ><a href="#" onclick="hidetag(\''+strs[i]+'\');" >'+strs[i]+'</a></li>','');
js_showtags.innerHTML = js_showtags.innerHTML+'<li id="tag_'+strs[i]+'" ><a href="#" onclick="hidetag(\''+strs[i]+'\');" >'+strs[i]+'</a></li>';
document.getElementById('tags').value=document.getElementById('tags').value.replace()+strs[i]+',';}
    } 
}

</script>
EOF;
}
?>


<?php
mysql_close($con);
echo runtime();
?>
