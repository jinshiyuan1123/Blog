<?php
$codename="Axublog";$codeversion="1.1.1"; $codeurl="http://www.axublog.com"; 
global $codename,$codeversion,$codeurl,$cachepath;
$fromip=$_SERVER['REMOTE_ADDR'];
$www=$_SERVER["HTTP_HOST"];
if($fromip=='::1'&&$www='locahost'){$fromip='127.0.0.1';}
$file='../'.$cachepath.$fromip.'.php';
#-------

function chkadcookie(){
		if(@$_SESSION["chkad"]==''||@$_SESSION["chkadtime1"]==''){
global $date,$cachepath,$fromip,$www,$file;
if(!file_exists($file)){header("Content-type:text/html; charset=utf-8");tiao();exit;}
$str=file_get_contents($file,'r');
$str=authcode($str, 'DECODE', 'key',0);
$result = array(); 
preg_match_all("/\[user\](.*)\[\/user\]/i",$str, $result); 
$txtuser=$result[1][0]; 
preg_match_all("/\[time\](.*)\[\/time\]/i",$str, $result); 
$txttime=$result[1][0]; 
preg_match_all("/\[ip\](.*)\[\/ip\]/i",$str, $result); 
$txtip=$result[1][0]; 
if($txtuser==''||$txtip==''||!is_numeric($txttime)){header("Content-type:text/html; charset=utf-8");tiao();exit;}
if($txtuser<>$_SERVER['HTTP_USER_AGENT']||$txtip<>$fromip||$txttime<time()){header("Content-type:text/html; charset=utf-8");tiao();exit;}
$_SESSION["chkadtime2"]=$txttime;
		}else{if(@$_SESSION["chkadtime2"]<time()){header("Content-type:text/html; charset=utf-8");tiao();exit;}}
}
#-------

function loginpass($str){
global $webauthor;
global $date,$cachepath,$file,$fromip;
$str=time()+$str;
$txtchkad="[user]".$_SERVER['HTTP_USER_AGENT'].'[/user][ip]'.$fromip.'[/ip][time]'.$str.'[/time]';
$_SESSION["chkad"]=$txtchkad;
$_SESSION["chkadtime1"]=time();
$_SESSION["chkadtime2"]=$str;
 if(!file_exists('../'.$cachepath)){mkdir('../'.$cachepath);}
$html="<?
#".authcode(@$txtchkad, 'ENCODE', 'key',0)."
?>";
file_put_contents ($file,$html);
}
#-------

function tiao(){
		?>
<script>
setTimeout("javascript:parent.location.href='login.php'", 10);  
</script>
	<?
}
#-------

function loginexit(){
setcookie("tagshu",'', time()+9999999,"/; HttpOnly" , "",'');
 unset($_SESSION["chkad"]); unset($_SESSION["chkadtime1"]);
 global $date,$cachepath,$file;
if(file_exists($file)){unlink($file);}
 echo '<script>location.href="login.php";</script>';
}
#-------
	
function jsloginexit(){
setcookie("tagshu",'', time()+9999999,"/; HttpOnly" , "",'');
 unset($_SESSION["chkad"]);
$jieguo= '<script>alert("exit succes!");location.href="login.php";</script>';
$json_arr = array("jieguo"=>$jieguo);
$json_obj = json_encode($json_arr);
echo $json_obj;
}
#-------

function jsloginpost(){
global $tabhead;
global $txtchk;
@$user=$_POST["user"];
@$psw=$_POST["psw"];$psw = authcode(@$psw, 'ENCODE', 'key',0); 
@$loginlong=$_POST["loginlong"];
$chk=sqlguolv();
if($chk==1){
$json_arr = array("jieguo"=>"<div id=redmsg>登录失败：发现非法字符！</div>");
$json_obj = json_encode($json_arr);
echo $json_obj;die();
}
#-------

#setcookie("lggqsj",date('Y-m-d H:i:s',time()+$loginlong), time()+60*60*24,"/; HttpOnly" , "",'');

$tab=$tabhead."adusers";
$chk=" where adnaa='".$user."' and adpss='".$psw."' ";
mysql_select_db($tab);
$sql = mysql_query("select * from ".$tab.$chk);
if(!$sql){$jieguo="<div id=redmsg>(数据库查询失败!)</div>";}else{
	$num=mysql_num_rows($sql);
				if($num==0){$jieguo='<div id=redmsg>登录失败：账户或密码错误！</div>';}
				else{
				loginpass($loginlong);
				$chkmoblie=isMobile();
				if($chkmoblie==1){$jieguo='<div id=bluemsg>登录成功！正在前往<a href="wap.php">后台</a>。。。</div><script>setTimeout("javascript:parent.location.href=\'wap.php\'", 1000);  </script>';}else{$jieguo='<div id=bluemsg>登录成功！正在前往<a href="index.php">后台</a>。。。</div><script>setTimeout("javascript:parent.location.href=\'index.php\'", 1000);  </script>';}
				}
}
$json_arr = array("jieguo"=>$jieguo);
$json_obj = json_encode($json_arr);
echo $json_obj;
}
#-------





?>