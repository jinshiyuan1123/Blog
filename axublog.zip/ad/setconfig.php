<?php require_once('all.php');chkadcookie();?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>后台管理</title>
    <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" type="text/css" href="css/right.css">

  </head>
<body> 
<div id=rightmenu>
<div id=rightmenu_top>
<ul>
<li><a  target="main" href='setconfig.php'><b>您的位置：基本设置</b></a> 
&nbsp;&nbsp;<a  target="main" href='?g=setzztj'><b>站长统计代码</b></a>
&nbsp;&nbsp;<a  target="main" href='?g=friendlinks'><b>友情链接</b></a>
</li>
</ul>
</div>
<ul id=setconfig>
<?php
@$g=$_GET["g"];
    switch ($g)
    {
default:index();break; 
case "index":index();break; 
case "save":save();break; 
case "setzztj":setzztj();break; 
case "setzztjsave":setzztjsave();break; 
case "friendlinks":friendlinks();break; 
case "addfriendlinks":addfriendlinks();break; 
case "delfriendlinks":delfriendlinks();break; 
    }
?>


</ul></div> 
  </body>
</html>

<?
function index(){
	global $root,$dbuser,$dbpsw,$dbname,$tabhead,$webname,$webkeywords,$webinfo,$weburl,$webauthor,$webbegindate,$pagenum,$cachepath,$date,$starttime,$themepath,$artpath,$tagpath,$webicp,$setsearchsecond,$setsearchtimes;
?>
<form id="frm" name="frm" method="post" action="?g=save">
<p>网站地址<input maxlength="200" style="" value="<?=$weburl?>" name="1" /> 如http://localhost/</p>
<p>建立日期<input maxlength="200" style="" value="<?=$webbegindate?>" name="2" /> 如2017-05-20</p>
<p>网站标题<input maxlength="200" style="" value="<?=$webname?>" name="3" /></p>
<p>关 键 字<input maxlength="200" value="<?=$webkeywords?>" name="4" /> 网站关键字keywords,字数50以内</p>
<p>网站描述<textarea name="5" cols="" rows="2" style="color:#333"><?=$webinfo?></textarea> 网站描述description,字数150以内</p>
<p>默认编辑<input maxlength="200"  value="<?=$webauthor?>" name="6" /> 在编辑文章时默认显示的编辑</p>
<p>文章路径<input maxlength="200" style="" value="<?=$artpath?>" name="7" /> 
文章生成html页面的存放路径，如post/</p>
<!--
<p>文章链接<input maxlength="200" style="" value="{$weburl}{$artpath}{$htmlname}" name="artpathtype" id="artpathtype" /> </p>
<p ><label><input  type="radio" name="radio_artpathtype" value="{$weburl}{$artpath}{$htmlname}" onclick="document.getElementById('artpathtype').value=this.value" />&nbsp;{$weburl}{$artpath}{$htmlname}</label><br><br>
<label><input  type="radio" name="radio_artpathtype" value="{%host%}index.php/tags-{%id%}_{%page%}.html" onclick="document.getElementById('artpathtype').value=this.value" />&nbsp;{%host%}index.php/tags-{%id%}_{%page%}.html</label><br><br>
<label><input  type="radio" name="radio_artpathtype" value="{%host%}tags-{%id%}_{%page%}.html" onclick="document.getElementById('artpathtype').value=this.value" />&nbsp;{%host%}tags-{%id%}_{%page%}.html</label><br><br>
<label><input  name="radio_artpathtype" type="radio" value="{%host%}tags-{%alias%}_{%page%}.html" onclick="document.getElementById('artpathtype').value=this.value" />&nbsp;{%host%}tags-{%alias%}_{%page%}.html</label></p>
//-->
<p>标签路径<input maxlength="200" style="" value="<?=$tagpath?>" name="8" /> tags生成html页面的存放路径，如tags/</p>
<!--
<p>标签链接<select name=tagpathtype  id=select><option>文件形式，如http://www.axublog.com/tags/别名.html</option><option>文件夹形式，如http://www.axublog.com/tags/别名/</option></select></p>
//-->
<p>缓存路径<input maxlength="200" style="" value="<?=$cachepath?>" name="9" /> 网站生成临时文件路径，如cache/</p>
<p>备 案 号<input maxlength="200" value="<?=$webicp?>" name="10" /> 网站备案号,如沪ICP备XXXXXX号</p>
<p>搜索时间<select  name="11" >
<?
for ($i=0; $i<=15; $i++){
	$chk='';if($i==$setsearchsecond){$chk="selected=selected";}
    echo "<option ".$chk." value=".$i."  >".$i."</option>";
}
?>
</select> 限制搜索时间间隔(秒)，0即为不限制，如5，表示5秒内仅可搜索1次</p>
<p>搜索次数<select  name="12" >
<?

for ($i=0; $i<=50; $i++){
	$chk='';if($i==$setsearchtimes){$chk="selected=selected";}
    echo "<option ".$chk." value=".$i."  >".$i."</option>";
}
?>
</select> 限制搜索次数，0即为不限制，如10，表示1个用户最多可搜索10次，关闭浏览器将重新统计次数</p>
<br><span id=setconfig_blank> </span><a  id=btn_yellow onclick="frm.submit()">保存设置</a><br><br>
</form>
<?	
}
?>
 
<?function save(){
global $root,$dbuser,$dbpsw,$dbname,$tabhead,$webname,$webkeywords,$webinfo,$weburl,$webauthor,$webbegindate,$pagenum,$cachepath,$date,$starttime,$themepath,$artpath,$tagpath,$webicp,$setsearchsecond,$setsearchtimes;
$file="../cmsconfig.php";
$text = file_get_contents($file);
$text2=$text;
$text2=str_replace('$weburl="'.$weburl.'"','$weburl="'.$_POST[1].'"',$text2);
$text2=str_replace('$webbegindate="'.$webbegindate.'$webbegindate="','"'.$_POST[2].'"',$text2);
$text2=str_replace('$webname="'.$webname.'"','$webname="'.$_POST[3].'"',$text2);
$text2=str_replace('$webkeywords="'.$webkeywords.'"','$webkeywords="'.$_POST[4].'"',$text2);
$text2=str_replace('$webinfo="'.$webinfo.'"','$webinfo="'.$_POST[5].'"',$text2);
$text2=str_replace('$webauthor="'.$webauthor.'"','$webauthor="'.$_POST[6].'"',$text2);
$text2=str_replace('$artpath="'.$artpath.'"','$artpath="'.$_POST[7].'"',$text2);
$text2=str_replace('$tagpath="'.$tagpath.'"','$tagpath="'.$_POST[8].'"',$text2);
$text2=str_replace('$cachepath="'.$cachepath.'"','$cachepath="'.$_POST[9].'"',$text2);
$text2=str_replace('$webicp="'.$webicp.'"','$webicp="'.$_POST[10].'"',$text2);
$text2=str_replace('$setsearchsecond="'.$setsearchsecond.'"','$setsearchsecond="'.$_POST[11].'"',$text2);
$text2=str_replace('$setsearchtimes="'.$setsearchtimes.'"','$setsearchtimes="'.$_POST[12].'"',$text2);
?>

<div id=setconfig_ok><?
if(file_put_contents ($file, $text2)){echo"保存设置成功！";} 
else{echo"保存设置失败！";}
?></div>
<form id="frm" name="frm" method="post" action="?g=save">
<p>网站地址<input maxlength="200" style="" value="<?=$_POST[1]?>" name="1" /> 如http://localhost/</p>
<p>建立日期<input maxlength="200" style="" value="<?=$_POST[2]?>" name="2" /> 如2017-05-20</p>
<p>网站标题<input maxlength="200" style="" value="<?=$_POST[3]?>" name="3" /></p>
<p>关 键 字<input maxlength="200" value="<?=$_POST[4]?>" name="4" /> 网站关键字keywords,字数50以内</p>
<p>网站描述<textarea name="5" cols="" rows="3" style="color:#333"><?=$_POST[5]?></textarea> 网站描述description,字数150以内</p>

<p>默认编辑<input maxlength="200"  value="<?=$_POST[6]?>" name="6" /> 在编辑文章时默认显示的编辑</p>
<p>文章路径<input maxlength="200" style="" value="<?=$_POST[7]?>" name="7" /> 
文章生成html页面的存放路径，如post/</p>
<p>标签路径<input maxlength="200" style="" value="<?=$_POST[8]?>" name="8" /> tags生成html页面的存放路径，如tags/</p>
<!--
<p>标签链接<select name=tagpathtype  id=select><option>文件形式，如http://www.axublog.com/tags/别名.html</option><option>文件夹形式，如http://www.axublog.com/tags/别名/</option></select></p>
//-->
<p>缓存路径<input maxlength="200" style="" value="<?=$_POST[9]?>" name="9" /> 网站生成临时文件路径，如cache/</p>
<p>备案号<input maxlength="200" value="<?=$_POST[10]?>" name="10" /> 网站备案号,如沪ICP备XXXXXX号</p>
<p>搜索时间<select  name="11" >
<?
for ($i=0; $i<=15; $i++){
	$chk='';if($i==$_POST[11]){$chk="selected=selected";}
    echo "<option ".$chk." value=".$i."  >".$i."</option>";
}
?>
</select> 限制搜索时间间隔，0即为不限制，如5</p>
<p>搜索次数<select  name="12" >
<?

for ($i=0; $i<=15; $i++){
	$chk='';if($i==$_POST[12]){$chk="selected=selected";}
    echo "<option ".$chk." value=".$i."  >".$i."</option>";
}
?>
</select> 限制搜索次数，0即为不限制，如10</p>
<br><span id=setconfig_blank> </span><a  id=btn_yellow onclick="frm.submit()">保存设置</a><br><br>
</form>
<?}?>


<?
function setzztj(){
$file='../theme/tongji.js';
$text=file_get_contents ($file);
?>
<form id="frm" name="frm" method="post" action="?g=setzztjsave">
<p><textarea name="1" cols="" style="width:600px;" rows="8" style="color:#333"><?=$text?></textarea>统计代码,如百度统计，CNZZ统计，51LA统计
</p>
<p>如：var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1262193706'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s19.cnzz.com/stat.php%3Fid%3D1262193706%26show%3Dpic' type='text/javascript'%3E%3C/script%3E"));</p>

<br><span id=setconfig_blank> </span><a  id=btn_yellow onclick="frm.submit()">保存设置</a><br><br>
</form>
<?	
}

function setzztjsave(){
$file='../theme/tongji.js';
file_put_contents ($file,$_POST[1]);
?>
<p>保存成功</p>
<?	
}


function friendlinks(){
	global $date;
$file='../theme/friendlinks.txt';
if (!file_exists($file))  
    {
    $a=array(array('Axublog官网','http://www.axublog.com','axublog是一款PHP个人博客系统，努力成为最优秀国产博客建站系统！',$date)); 
$text='<?php $rows='.var_export($a,true).';'; 
file_put_contents ($file,$text);
    } 
require_once($file);
$_SESSION['friendlinks']=$rows;
$shu=count($rows);

if($_POST[a2]==''){$url='http://';}else{$url=$_POST[a2];}
if($_POST[a4]==''){$riqi=$date;}else{$riqi=$_POST[a4];}
$id=$_GET[id];
if(is_numeric( $id )&&$id<$shu&&$id>-1){$chkid='<p>正在修改第'.($id+1).'条链接信息：</p>';

}
?>
<div id=friendlinks>
<ul id=top>
<li id=ico>序号</li>
<li id=name>网站名称</li>
<li id=date>添加日期</li>
<li id=set>设置</li>
</ul>
<?for($i=0;$i<$shu;$i++){?>
<ul>
<li id=ico><?=$i+1?></li>
<li id=name><a href="<?=$rows[$i][1]?>" title="<?=$rows[$i][2]?>" target=_blank><?=$rows[$i][0]?></a></li>
<li id=date><?=$rows[$i][3]?></li>
<li id=set>
<a href='?g=friendlinks&id=<?=$i?>'><img title=编辑修改 src="images/edit.png"></a>
<a onclick="if(confirm('确定 [删除] 吗?')){location.href='?g=delfriendlinks&id=<?=$i?>';}"><img  title=删除 src="images/delete.png"></a>
</li>
</ul>
<?}?>
<div id=friendlinks_shu>友情链接：<?=$shu?>个</div>

</div>
	<script>
	function chk(){
	if(frm.a1.value==''){alert("请填写名称！");frm.a1.focus();return false;}
	else if(frm.a2.value==''){alert("请填写网址！如：http://www.axublog.com");frm.a2.focus();return false;}
	else if(frm.a3.value==''){alert("请填写描述！");frm.a3.focus();return false;}
	else if(frm.a4.value==''){alert("请填写日期！");frm.a4.focus();return false;}
	else{frm.submit();}	
					}
</script>
<form id="frm" name="frm" method="post" action="?g=addfriendlinks">
<div id=friendlinks_right>
<?=$chkid?>
<p>名称<input maxlength="100" style="" value="<?=$_POST[a1]?>" name="a1" /></p>
<p>网址<input maxlength="100" style="" value="<?=$url?>" name="a2" /></p>
<p>描述<input maxlength="100" style="" value="<?=$_POST[a3]?>" name="a3" /></p>
<p>日期<input maxlength="100" style="" value="<?=$riqi;?>" name="a4" id=4 /></p>
<br><a id=abtn_green onclick="chk()" >添加友情链接</a>
</form>
</div>
<?	
}

function delfriendlinks(){
$id=$_GET['id'];	
$file='../theme/friendlinks.txt';
$rows=$_SESSION['friendlinks'];
array_splice($rows,$id,1); 
$text='<?php $rows='.var_export($rows,true).';'; 
file_put_contents ($file,$text);
echo '<p>删除友情链接成功</p><script>location.href="?g=friendlinks"</script>';
}


function addfriendlinks(){
$file='../theme/friendlinks.txt';
$rows=$_SESSION['friendlinks'];
$a='/%3C|\<|\=|%27|%22|\>|%3E|\||\\\|\;|\"|\'|\\*|\*/i';
$_POST=preg_replace($a,'',$_POST);
array_push($rows,array($_POST[a1],$_POST[a2],$_POST[a3],$_POST[a4]));
$text='<?php $rows='.var_export($rows,true).';'; 
file_put_contents ($file,$text);
echo '<p>添加友情链接成功</p><script>location.href="?g=friendlinks"</script>';
}


?>
