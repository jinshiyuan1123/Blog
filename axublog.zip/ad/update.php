<?php 
include_once("all.php");chkadcookie();
header("Content-type:text/html; charset=utf-8");
?>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style>body{
font-size:13px;
margin:0;
padding:0;}
#e{margin-top:3px;}
</style>
</head>
<body>
<?
$url='http://www.axublog.com/update';
$zipurl='http://pic.axublog.com/axublog.zip';
$zippath='../cache/axublog.zip';
 if(!file_exists('../'.$cachepath)){mkdir('../'.$cachepath);}

@$g=$_GET["g"];
    switch ($g)
    {
    case "jieya":jieya();break; 
	case "download":download();break; 
    default:index();break; 
    }	


function index() {
global $codeversion,$url,$zipurl,$zippath,$date,$getnewversion,$dateofgetnewversion;
if($dateofgetnewversion==date('Y-m-d')&&$getnewversion<>''){header("Content-type:text/html; charset=utf-8");echo"最新版本号".$getnewversion;EXIT;}
$text=file_get_contents($url);
$text=str_replace(' ','',$text); 
$text=str_replace('\n','',$text); 
$text=str_replace('\r','',$text); 
if($text==''){echo' 对不起，暂时无法获取远程更新信息，可能是网络或服务器故障';}
if($codeversion==$text){echo('已经是最新版本，不需要更新。');}else{echo'有新版本可更新';}
configset("getnewversion",$text);
configset("dateofgetnewversion",date('Y-m-d'));
}
#

function download() {
global $codeversion,$url,$zipurl,$zippath,$date,$getnewversion,$dateofgetnewversion;
$text=file_get_contents($url);
$text=str_replace(' ','',$text); 
$text=str_replace('\n','',$text); 
$text=str_replace('\r','',$text); 
configset("getnewversion",$text);
configset("dateofgetnewversion",date('Y-m-d'));
			if($text==''){echo' 对不起，暂时无法获取远程更新信息，可能是网络或服务器故障';}
				else{

ob_start();
@set_time_limit(30);//设置该页面最久执行时间为300秒
$url=$zipurl;//要下载的文件
$newfname=$zippath;//本地存放位置，也可以是E:\Temp\QQ2010Beta3.exe，这样做在Win7下要设置相应权限
$file = fopen ($url, "rb");
if (!$file){echo'下载更新包失败！';}else{
	?>
<table border="0" width="300" style="font-size:13px;margin-top:0px;">  <tr>
    <td width="100"><div id="progressbar" style="float:left;width:1px;text-align:center;color:#FFFFFF;background-color:#0066CC"></div>
      <div id="progressText" style=" float:left">0%</div></td>
	      <td width="120">下载进度<span id="filesize"></span>/<span id="downloaded"></span>KB</td>
  </tr></table>
<script type="text/JavaScript">
//文件长度
var filesize=0;
function $(obj) {return document.getElementById(obj);}

//设置文件长度
function setFileSize(fsize) {
    filesize=fsize;
    $("filesize").innerHTML=fsize;
}

//设置已经下载的,并计算百分比
function setDownloaded(fsize) {
    $("downloaded").innerHTML=fsize;
    if(filesize>0) {
        var percent=Math.round(fsize*100/filesize);
        $("progressbar").style.width=(percent+"%");
        if(percent>0) {
            $("progressbar").innerHTML=percent+"%";
            $("progressText").innerHTML="";
        } else {
            $("progressText").innerHTML=percent+"%";
        }
    }
}
</script>
<?PHP
    //获取文件大小
    $filesize = -1;
    $headers = get_headers($url, 1);
    if ((!array_key_exists("Content-Length", $headers))) $filesize=0;
    $filesize = $headers["Content-Length"];
    
    //不是所有的文件都会先返回大小的，有些动态页面不先返回总大小，这样就无法计算进度了
    if ($filesize != -1) {
        echo "<script>setFileSize(".intval($filesize/1024).");</script>";//在前台显示文件大小
    }
    $newf = fopen ($newfname, "wb");
    $downlen=0;
    if ($newf) {
        while(!feof($file)) {
            $data=fread($file, 1024 * 8 );//默认获取8K
            $downlen+=strlen($data);//累计已经下载的字节数
            fwrite($newf, $data, 1024 * 8 );
            echo "<script>setDownloaded(".intval($downlen/1024).");</script>";//在前台显示已经下载文件大小
            ob_flush();
            flush();
        }
    }
    if ($file) {
        fclose($file);
    }
    if ($newf) {
        fclose($newf);
    }
	echo'<meta http-equiv="refresh" content="2; url=?g=jieya">';
}
						}
}


function download2() {
global $codeversion,$url,$zipurl,$zippath,$date,$getnewversion,$dateofgetnewversion;
$text=file_get_contents($url);
$text=str_replace(' ','',$text); 
$text=str_replace('\n','',$text); 
$text=str_replace('\r','',$text); 
configset("getnewversion",$text);
configset("dateofgetnewversion",date('Y-m-d'));
			if($text==''){echo' 对不起，暂时无法获取远程更新信息，可能是网络或服务器故障';}
				else{
						if(curl_download($zipurl, $zippath)){
							echo'正在下载更新文件......';
							}
						else{echo'下载更新文件失败';}
						}
}

function jieya() {
global $codeversion,$url,$zipurl,$zippath;
$archive = new PclZip($zippath);  
	if ($archive->extract('../') == 0) {  
	die("Error : ".$archive->errorInfo(true));  
	}
	else{echo '<div id=e>正在解压，更新完成</div>';
			$name=basename(dirname(__FILE__));
			#echo dirname(__FILE__)."<br>";
			#echo realpath(dirname(__FILE__).'/../').'\ad'."<br>";
			#die();
							if($name!='ad'){
							@recurse_copy(realpath(dirname(__FILE__).'/../').'/ad',dirname(__FILE__)); 
							@deldir(realpath(dirname(__FILE__).'/../').'/ad');
							}
			}
}
?>
</body>
</html>