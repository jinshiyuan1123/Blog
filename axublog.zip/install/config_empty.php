<?php 
error_reporting(E_ERROR |  E_PARSE);//报告运行时错误
#session_start();
#header("Content-type:text/html; charset=utf-8");
@define('webpath',str_replace('\\','/',realpath(dirname(__FILE__).'/../'))); //定义站点目录

$root="@root@";                   #MySQL服务器 
$dbuser="@dbuser@";           #MySQL用户名 
$dbpsw="@dbpsw@";           #MySQL密码 
$dbname="@dbname@";               #数据库名
$tabhead="@tabhead@";               #表前缀

$webname="@webname@";             #网站名称
$webkeywords="@webkeywords@";             #网站关键字
$webinfo="@webinfo@";             #网站简介
$weburl="@weburl@";             #网站链接,根目录可填写/，便于移动网站
$webauthor="@webauthor@";             #网站编辑，前台显示
$webbegindate="@webbegindate@";             #网站建立日期
$webicp="@webicp@";             #网站备案号

$pagenum="20";                       #每页显示文章数 
$cachepath="cache/";
$setsearchsecond="5";    			#限制搜索时间间隔，0即为不限制，如5
$setsearchtimes="10";    			#限制搜索次数，0即为不限制，如5

date_default_timezone_set('PRC');
$date=date('Y-m-d H:i:s');
$starttime=microtime(true);   

$configfile="cmsconfig.php"; 
$themepath="theme/default/";
$themeshu="1";  
$apppath="app/";
$appshu="1";      
$artpath="post/";        
$tagpath="tags/";   

$getnewversion="1.0.9";
$dateofgetnewversion="2018-02-13";
#[last]
$con=mysql_connect($root,$dbuser,$dbpsw);
if(!$con){echo "<font color=red>(连接到MYSQL失败,请检查MYSQL信息!)</font>";return false;}
mysql_select_db($dbname);
mysql_query("SET NAMES 'utf8'");

#global $root,$dbuser,$dbpsw,$dbname,$tabhead,$webname,$webkeywords,$webinfo,$weburl,$webauthor,$webbegindate,$pagenum,$cachepath,$date,$starttime,$artpath,$tagpath,$themepath,$themeshu,$apppath,$appshu,$configfile,$webicp,$setsearchsecond,$setsearchtimes;
?>