<?include_once('../all.php');chkadcookie();?>
<?
@$text=file_get_contents ('info.txt');
if($text==''){die('读取info.txt配置信息错误！请检测info.txt情况！');}
preg_match("/<name>(.*)<\/name>/i", $text, $name);$name=$name[1];
preg_match("/<version>(.*)<\/version>/i", $text, $version);$version=$version[1];
preg_match("/<info>(.*)<\/info>/i", $text, $info);$info=$info[1];
preg_match("/<url>(.*)<\/url>/i", $text, $url);$url=$url[1];
preg_match("/<author>(.*)<\/author>/i", $text, $author);$author=$author[1];
preg_match("/<lastdate>(.*)<\/lastdate>/i", $text, $lastdate);$lastdate=$lastdate[1];
preg_match("/<type>(.*)<\/type>/i", $text, $type);$type=$type[1];
preg_match("/<switch>(.*)<\/switch>/i", $text, $switch);$switch=$switch[1];	
?>
<!DOCTYPE html><html>  <head>
    <meta charset="utf-8">
	    <title><?=$name?> <?=$version?> 后台</title>
    <link rel="stylesheet" type="text/css" href="../images/right.css"> 
		<script type="text/javascript" src="../jquery-1.8.2.min.js"></script>
			<script>
			function cjrk(i,str){
htmlobj=$.ajax({url:"ajax.php?g=caijiruku&word="+str,async:false});
$("#caiji"+i).html(htmlobj.responseText);	
}
			
			
jQuery(function($){ 
//全选 
	$("#chooseall").click(function(){ 
	$("input[name='checkbox']").attr("checked","true"); 
	}) 
		
	//取消全选 
	$("#unchooseall").click(function(){ 
	$("input[name='checkbox']").removeAttr("checked"); 

	}) 
	
}) 
//jQuery end

</script>
</head>
<body> 
<?
session_start();
$word=$_GET["word"];
$update=$_GET["update"];
if($word==''){die();}
date_default_timezone_set('PRC');$datepoint=date('YmdH');
$cache='list/'.$word.'.html';
#echo $cache;
?>

<div id=rightmenu>
<div id=rightmenu_top><ul><li> <a href="index.php"><?=$name?> <?=$version?> 后台</a> - weixin采集列表：<b><a href=""><?=$word?></a></b></li></ul></div>
<ul>
<span id="jieguo"></span>
<div id=artlist>
<ul id=top>
<li id=ico>ID</li>
<li id=title>标题</li>
<li id=tags>公众号</li>
<li id=date>操作</li>
</ul>

<?
$url1=='http://weixin.sogou.com/weixin?type=2&ie=utf8&page=1&query='.$word;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url1);
curl_setopt($ch, CURLOPT_HEADER,0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);//禁止调用时就输出获取到的数据
if (ini_get('open_basedir') == '' && ini_get('safe_mode' == 'Off')) {    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);}
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,false);
$text2 = curl_exec($ch);
curl_close($ch);
$headers['CLIENT-IP'] = '192.168.1.1';  
$headers['X-FORWARDED-FOR'] = '192.168.1.1'; 
 $headerArr = array();  
foreach( $headers as $n => $v ) {  
    $headerArr[] = $n .':' . $v;   
}
$url='http://weixin.sogou.com/weixin?type=2&query='.$word.'&ie=utf8';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_HEADER,0);
curl_setopt ($ch, CURLOPT_HTTPHEADER , $headerArr );  //构造IP
curl_setopt ($ch, CURLOPT_REFERER, $url1);   //构造来路
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);//禁止调用时就输出获取到的数据
if (ini_get('open_basedir') == '' && ini_get('safe_mode' == 'Off')) {    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);}
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,false);
$text = curl_exec($ch);
curl_close($ch);
#die($text);
$pattern='/<a target="_blank" href="(.*?)" /is'; preg_match_all($pattern,$text,$match); 
$pattern='/<h3>(.*?)<\/h3>/is'; preg_match_all($pattern,$text,$match2); 
$pattern='/uigs="article_account_(.*?)<\/a><span class="s2">/is'; preg_match_all($pattern,$text,$match3); 
$shu=count($match[0]);
for($i=1;$i<=$shu;$i++){
$links=$match[1][$i-1]; 
$title=$match2[1][$i-1]; 
$author=$match3[1][$i-1];$author=str_replace(($i-1).'">','',$author); 	
echo'<ul id=list4 >
<li id=ico>'.$i.'</li>
<li id=title>'.$title.'</li>
<li id=tags>'.$author.'</li>
<li id=date><a onclick=cjrk("'.$i.'","'.$links.'") >采集</a><span id=caiji'.$i.'></span></li>
</ul>';
}
?>
</div>
<br>
<span id="artlist_btn">

<a  id=btn_blue  onclick="location.href='#';">采集入库</a>
<a  id=chooseall  >全选</a>
<a  id=unchooseall  >取消全选</a>
<a  id=btn_blue href="?g=update">更新实时热点</a>
</span>
<br><br>
</ul></div>
</body></html>






