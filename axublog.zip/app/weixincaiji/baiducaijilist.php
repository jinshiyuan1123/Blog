<?include_once('../all.php');chkadcookie();?>
<?
session_start();
@$text=file_get_contents ('info.txt');
if($text==''){die('读取info.txt配置信息错误！请检测info.txt情况！');}
preg_match("/<name>(.*)<\/name>/i", $text, $name);$name=$name[1];
preg_match("/<version>(.*)<\/version>/i", $text, $version);$version=$version[1];
preg_match("/<info>(.*)<\/info>/i", $text, $info);$info=$info[1];
preg_match("/<url>(.*)<\/url>/i", $text, $url);$url=$url[1];
preg_match("/<author>(.*)<\/author>/i", $text, $author);$author=$author[1];
preg_match("/<lastdate>(.*)<\/lastdate>/i", $text, $lastdate);$lastdate=$lastdate[1];
preg_match("/<type>(.*)<\/type>/i", $text, $type);$type=$type[1];
preg_match("/<switch>(.*)<\/switch>/i", $text, $switch);$switch=$switch[1];	
?>
<!DOCTYPE html><html>  <head>
    <meta charset="utf-8">
	    <title><?=$name?> <?=$version?> 后台</title>
    <link rel="stylesheet" type="text/css" href="../images/right.css"> 
		<script type="text/javascript" src="../jquery-1.8.2.min.js"></script>
			<script>
function cjrk(i,str,str2){
htmlobj=$.ajax({url:"ajax.php?g=caijiruku&link="+str+"&title="+str2+"&i="+i,async:false});
$("#caiji"+i).html(htmlobj.responseText);	
}
			
function jsfabu(i,str,str2){
htmlobj=$.ajax({url:"ajax.php?g=fabu&link="+str+"&title="+str2+"&i="+i,async:false});
$("#caiji"+i).html(htmlobj.responseText);	
}
		
jQuery(function($){ 
//全选 
	$("#chooseall").click(function(){ 
	$("input[name='checkbox']").attr("checked","true"); 
	}) 
		
	//取消全选 
	$("#unchooseall").click(function(){ 
	$("input[name='checkbox']").removeAttr("checked"); 

	}) 
	
}) 
//jQuery end

</script>
</head>
<body> 
<?
session_start();
$word=$_GET["word"];
$update=$_GET["update"];
if($word==''){die();}
date_default_timezone_set('PRC');$datepoint=date('YmdH');
$cache='list/'.$word.'.html';
#echo $cache;
?>

<div id=rightmenu>
<div id=rightmenu_top><ul><li> <a href="index.php"><?=$name?> <?=$version?> 后台</a> - baidu采集列表：<b><a href=""><?=$word?></a></b></li></ul></div>
<ul>
<span id="jieguo"></span>
<div id=artlist>
<ul id=top>
<li id=ico>ID</li>
<li id=title>标题</li>
<li id=tags>信息 </li>
<li id=date>操作 </li>
</ul>

<?
$url='http://www.baidu.com/s?ie=UTF-8&wd='.$word;
$_SESSION['tags']='';$_SESSION['tags']=$word;
$cache='baidulist/'.$word.'.html';
if(!file_exists($cache)){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_HEADER,0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION,1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,false);
$text1 = curl_exec($ch);
$pattern='/百度为您找到相关结果(.*?)<div id="foot">/is'; preg_match_all($pattern,$text1,$match); 
$text2=$match[1][0]; 
$pattern='/<div id="content_left">(.*?)<div id="rs"><div class="tt">相关搜索/is'; preg_match_all($pattern,$text2,$match); 
$text=$match[1][0]; 
curl_close($ch);
$cache=iconv("UTF-8",'GBK',$cache);
file_put_contents ($cache, $text);
}
else{$text = file_get_contents ($cache);}
//获取网址列表并缓存

$pattern='/href = "(.*?)"/is'; preg_match_all($pattern,$text,$match); 
$pattern='/<h3 class="t">(.*?)<\/h3>/is'; preg_match_all($pattern,$text,$match2); 
$shu=count($match[0]);$jscjall='';
for($i=1;$i<=$shu;$i++){
$links=$match[1][$i-1]; 
$title=$match2[1][$i];$title=strip_tags($title) ;$title=str_replace("\n",'',$title);$title=str_replace(" ",'',$title);$title=str_replace("|",'',$title);
 $regex = "/\/|\~|\!|\@|\#|\\$|\%|\^|\&|\*|\(|\)|\（|\）|\_|\+|\{|\}|\:|\<|\>|\?|\[|\]|\,|\.|\/|\;|\'|\`|\-|\=|\\\|\||\s+/";
$link2=preg_replace($regex,"",$links);
$cache='content/'.$link2.'.html';
echo"<ul id=list4 >
<li id=ico>$i</li>
<li id=title><a target=_blank href='ajax.php?g=caijiruku&link=$links&title=$title'>$title</a></li>
<li id=tags><a target=_blank href='$links'>原文链接</a> <a target=_blank href='$cache'>查看缓存</a></li>
<li id=date><a onclick=cjrk('$i','$links','$title') >采集</a> <a onclick=jsfabu('$i','$links','$title') >发布</a> <span id=caiji$i ></span></li>
</ul>";
$jscjall=$jscjall."cjrk('$i','$links','$title');\r\n";
$jsfabuall=$jsfabuall."jsfabu('$i','$links','$title');\r\n";
}
?>
<script>
function jscjall(){
<?=$jscjall;?>
}

function jsfabuall(){
<?=$jsfabuall;?>
}
</script>
</div>
<br>
<span id="artlist_btn">
<a  id=btn_blue  onclick="jscjall();">全部采集</a>
<a  id=btn_blue  onclick="jsfabuall();">全部发布</a>
<a  id=btn_blue  onclick="">全部保存草稿</a>
<a  id=btn_blue href="?g=update">更新实时热点</a>
</span>
<br><br>
</ul></div>
</body></html>
