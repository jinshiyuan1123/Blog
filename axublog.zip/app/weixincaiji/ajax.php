<?php require_once('../all.php');chkadcookie();require_once('../../class/pinyin.php');?>
<?php 
header("Content-type:text/html;charset=utf-8");
$g=$_GET["g"];
    switch ($g)
    {
case "shoulucaiji":shoulucaiji();break; 
case "caijiruku":caijiruku();break; 
case "wncaiji":wncaiji();break; 
case "fabu":fabu();break; 
    }

	
function shoulucaiji(){
session_start();
$word=$_GET["word"];
$update=$_GET["update"];
if($word==''){die();}
#echo '<a target=_blank href="ajax.php?g=shoulucaiji&update=yes&word='.$word.'">刷新</a>';#die();
if($update=='yes'||$_SESSION['shoulucaiji'.$word]==''){
$cjurl='http://www.baidu.com/s?wd='.$word;
$text = file_get_contents($cjurl);  
#$text=iconv('GBK',"UTF-8",$text);
preg_match('/百度为您找到相关结果约(.*)个/is',$text,$match);
$shu=str_replace(',','',$match[0]);
$shu=str_replace('个','',$shu);
$_SESSION['shoulucaiji'.$word]=$shu;
}
#if $update=='yes'
elseif($_SESSION['shoulucaiji'.$word]!=''){$shu=$_SESSION['shoulucaiji'.$word];
}
$shu=str_replace('百度为您找到相关结果约','',$shu);
$shu=abs($shu);
if($shu<80000){echo "<b>$shu</b>";}else{echo $shu;}
echo ' <a href="weixincaijilist.php?g=caijilist&word='.$word.'">微信</a> <a href="baiducaijilist.php?g=caijilist&word='.$word.'">百度采集列表</a>';
}	
//function


function wncaiji(){
session_start();
$word=$_GET["word"];
$title=$_GET["title"];
$update=$_GET["update"];
if($word==''||$title==''){die('err');}
$cache='content/'.$title.'.html';
echo $cache;
$cache=iconv("UTF-8",'GBK',$cache);


}	
//function




function caijiruku(){
session_start();
$i=$_GET["i"];
$title=$_GET["title"];
$link=$_GET["link"];
$update=$_GET["update"];
if($link==''||$title==''||$i==''){die('err');}
#$cache='content/'.$title.'.html';
#$cache=iconv("UTF-8",'GBK',$cache);
 $regex = "/\/|\~|\!|\@|\#|\\$|\%|\^|\&|\*|\(|\)|\（|\）|\_|\+|\{|\}|\:|\<|\>|\?|\[|\]|\,|\.|\/|\;|\'|\`|\-|\=|\\\|\||\s+/";
$link2=preg_replace($regex,"",$link);
$cache='content/'.$link2.'.html';

if(!file_exists($cache)){
	$url = $link;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_VERBOSE, true);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_NOBODY, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 20);
curl_setopt($ch, CURLOPT_AUTOREFERER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
// 下面两行为不验证证书和 HOST，建议在此前判断 URL 是否是 HTTPS
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
// $ret 返回跳转信息
$ret = curl_exec($ch);
// $info 以 array 形式返回跳转信息
$info = curl_getinfo($ch);
// 跳转后的 URL 信息
$retURL = $info['url'];
curl_close($ch);// 记得关闭curl

$text=	file_get_contents ($retURL);	
$bottom="<br>原文标题：$title<br>原文链接：$retURL";
$pattern='/<body(.*?)<\/body>/is'; preg_match_all($pattern,$text,$match); 
if(is_gb2312($text)=='gb2312'){$text=iconv('GBK',"UTF-8",$text);$bottom=iconv("UTF-8",'GBK',$bottom);}	//转化为UTF-8编码
if($match[1][0]==''){$text2=$text; }else{$text2='<body'.$match[1][0]; }

$text2=str_replace("<br>","",$text2);
$text2=str_replace("\r\n\r\n","",$text2);
$text2=str_replace("\r\r","",$text2);
$text2=str_replace("\n\n","",$text2);
$preg = "/<script[\s\S]*?<\/script>/i";
$text2 = preg_replace($preg,"",$text2,-1);    //第四个参数中的3表示替换3次，默认是-1，替换全部
$preg = "/<style[\s\S]*?<\/style>/i";
$text2 = preg_replace($preg,"",$text2,-1);    //第四个参数中的3表示替换3次，默认是-1，替换全部
$text2=strtolower($text2);
$text2=str_replace('</p>','$br$',$text2);
$text2=str_replace('</table>','$br$',$text2);
$text2=str_replace('</tr>','$br$',$text2);
$text2=str_replace('</div>','$br$',$text2);
$text2=str_replace('</h3>','$br$',$text2);
$text2=str_replace('</h2>','$br$',$text2);
$text2=str_replace('</h1>','$br$',$text2);
$text2=str_replace('</h4>','$br$',$text2);
$text2=str_replace('<br />','$br$',$text2);
$text2=str_replace('<br/>','$br$',$text2);
$text2=str_replace('<img','$img$',$text2);
$text2=strip_tags($text2);
$text2=str_replace('$br$','<br>',$text2);
$text2=str_replace('$img$','<img',$text2);
$text2=str_replace('\"','"',$text2);
$text2=str_replace("	",'',$text2);
$text2=str_replace("\r\n\r\n",'',$text2);
$text2=str_replace("\r\n \r\n",'',$text2);
$text2=str_replace('<br>
<br>','',$text2);
file_put_contents ($cache, $text2.$bottom);
echo strlen($text2).'字符 正在采集 ';
}
else{$text2=file_get_contents ($cache);echo strlen($text2);echo'字符 已采集并缓存';}
if(strlen($text2)<500){echo " 字符太少有问题";}
}	//function



function fabu(){
	session_start();
include_once('../all.php');
$i=$_GET["i"];
$title=$_GET["title"];
$link=$_GET["link"];
$update=$_GET["update"];
if($link==''||$title==''||$i==''){die('err');}

#$cache='content/'.$title.'.html';
#$cache=iconv("UTF-8",'GBK',$cache);
 $regex = "/\/|\~|\!|\@|\#|\\$|\%|\^|\&|\*|\(|\)|\（|\）|\_|\+|\{|\}|\:|\<|\>|\?|\[|\]|\,|\.|\/|\;|\'|\`|\-|\=|\\\|\||\s+/";
$link2=preg_replace($regex,"",$link);
$cache='content/'.$link2.'.html';
$text2=file_get_contents ($cache);$bianma='';
if(is_gb2312($text2)=='gb2312'){$text2=iconv('GBK',"UTF-8",$text2);$bianma='GBK';}else{$bianma='UTF-8';}if(strlen($text2)<500){echo "内容字符太少有问题";die();}
global $date,$tabhead,$webname,$webinfo,$weburl,$webauthor,$themepath,$artpath,$tagpath;
$htmlname=pinyin($title);
$content=$text2;#$content=gethttpimg($content);

$title=str_replace('-','_',$title);$title=str_replace('|','_',$title);$title=str_replace('——','_',$title);
#if($bianma='GBK'){$title=iconv('GBK',"UTF-8",$title);}
$a=explode('_',$title);$shu=count($a);$author=$a[$shu-1];if(strlen($author)>16||$author=='...'){$author="网络";}
if(strlen($title)>70){$title=substr($title,0,70);}	

$tags=$_SESSION['tags'];
if($tags==''){echo "tags无法获取";die();}$tags=htmlnameguolv($tags);
$pic=$weburl.'images/pic1.jpg';

$tab=$tabhead."arts";
mysql_select_db($tab);
$chk=" where htmlname='".$htmlname."'";
$sql = mysql_query("select * from ".$tab.$chk);
if(!$sql){echo "(数据库查询失败!)<br>";}
$num=mysql_num_rows($sql);
    if($num==0){
$sql="INSERT INTO ".$tab." (id,author,title,content,htmlname,type,hit,cdate,edate,tags,pic) VALUES (null,'".$author."','".$title."','".$content."','".$htmlname."','art',1,'".$date."','".$date."','".$tags."','".$pic."')";
if(mysql_query($sql)){echo"发布内容成功";}
else{echo"发布内容<font color=red>失败1</font><br>";return;}
$artid = mysql_insert_id();
addtags($tags,$artid);
    }    else{echo'html别名已存在！';}
}	//function



function is_gb2312($str)
{
    for($i=0; $i<strlen($str); $i++) {
        $v = ord( $str[$i] );
        if( $v > 127) {
            if( ($v >= 228) && ($v <= 233) )
            {
                if( ($i+2) >= (strlen($str) - 1)) return 'utf-8'; // not enough characters
                $v1 = ord( $str[$i+1] );
                $v2 = ord( $str[$i+2] );
                if( ($v1 >= 128) && ($v1 <=191) && ($v2 >=128) && ($v2 <= 191) ) // utf编码
                    return 'utf-8';
                else
                    return 'gb2312';
            }
        }
    }
    return 'utf-8';
}



?>
