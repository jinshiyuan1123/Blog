<?include_once('../all.php');chkadcookie();?>
<?
@$text=file_get_contents ('info.txt');
if($text==''){die('读取info.txt配置信息错误！请检测info.txt情况！');}
preg_match("/<name>(.*)<\/name>/i", $text, $name);$name=$name[1];
preg_match("/<version>(.*)<\/version>/i", $text, $version);$version=$version[1];
preg_match("/<info>(.*)<\/info>/i", $text, $info);$info=$info[1];
preg_match("/<url>(.*)<\/url>/i", $text, $url);$url=$url[1];
preg_match("/<author>(.*)<\/author>/i", $text, $author);$author=$author[1];
preg_match("/<lastdate>(.*)<\/lastdate>/i", $text, $lastdate);$lastdate=$lastdate[1];
preg_match("/<type>(.*)<\/type>/i", $text, $type);$type=$type[1];
preg_match("/<switch>(.*)<\/switch>/i", $text, $switch);$switch=$switch[1];	


?>
<!DOCTYPE html><html>  <head>
    <meta charset="utf-8">
	    <title><?=$name?> <?=$version?></title>
    <link rel="stylesheet" type="text/css" href="../images/right.css"> 
		<script type="text/javascript" src="../jquery-1.8.2.min.js"></script>
</head>
<body> 
<?
$g=$_GET["g"];
    switch ($g)
    {
case "contentlist":contentlist();break; 
case "caijiruku":caijiruku();break; 
    default:index();break; 
    }
?>


<?function index(){?>
<div id=rightmenu>
<?
?>
<div id=rightmenu_top><ul><li> <a href="index.php"><?=$GLOBALS['name']?> <?=$GLOBALS['version']?></li></ul></div>
<ul>
<span id="jieguo"></span>
<div id=artlist>
<ul id=top>
<li id=ico>排名</li>
<li id=set1>操作 </li>
<li id=name><?=$datepoint?>搜索词</li>
<li id=tags>搜索指数</li>
<li id=date>百度收录数</li>
</ul>


<ul id=list4 >
<li id=ico><?=$i?></li>
<li id=set>
<input type="checkbox" name="checkbox" value='<?=$i?>'>
采集入库
</li>
<li id=name><a target=_blank  href='http://www.baidu.com/baidu?wd=<?=$sousuoci?>' title=查看百度收录数 ><?=$sousuoci?></a></li>
<li id=tags><?=$sousuozhishu?></li>
<li id=date><span id=shoulu<?=$i?> ></span><script>zdcj1('<?=$i?>','<?=$sousuoci?>');</script></li>
</ul>



</div>
<br>
<span id="artlist_btn">
<a  id=btn_blue  onclick="location.href='#';">采集入库</a>
<a  id=chooseall  >全选</a>
<a  id=unchooseall  >取消全选</a>
<a  id=btn_blue href="?g=update">更新实时热点</a>
</span>
<br><br>
</ul>
</div>
</body></html>
<?}?>


<?function contentlist(){?>
<div id=rightmenu>
<div id=rightmenu_top><ul><li> <a href="index.php"><?=$name?> <?=$version?> 实时热点</a> - <b><a href="?g=contentlist">缓存列表</a></b></li></ul></div>
<ul>
<span id="jieguo"></span>
<div id=artlist>
<ul id=top>
<li id=ico>ID</li>
<li id=title>标题-以下为已采集内容</li>
<li id=tags>作者</li>
<li id=date>操作  <a>全部入库</a></li>
</ul>

<ul id=list4 >
<li id=ico>1</li>
<li id=title><a target=_blank href=''>德国发现遗留炸弹女星谭维维发文称自己被困当地_兵马俑在线</a></li>
<li id=tags></li>
<li id=date><a onclick=cjrk('1','http://www.baidu.com/link?url=VXRqXFpgbeApBDv-WiZQE_X9Zr4mm1sgXKw5r1xbXGAZtsIFauYrMYUXBYsAaEQkN3LMSHJOrbAlPWT4SFb2aK','德国发现遗留炸弹女星谭维维发文称自己被困当地_兵马俑在线') >采集</a><span id=caiji1 ></span></li>
</ul>

<?
$path_pattern = "content/*";
foreach(glob($path_pattern) as $file)      
				{
						if(!is_dir($file)){ 
						$file=iconv( "GB2312","UTF-8", $file);
						$file2=str_replace('../','',$file.'/');
							echo"<a href='?g=savechoose&path=".$file2."' title=使用此主题 ><img alt=使用此主题 src='".$file."/jietu.png' width=100></a><br><center>";
							echo $file."<br>"; 
							}
							}
?>




</div>
<br>
<span id="artlist_btn">

<a  id=btn_blue  onclick="location.href='#';">采集入库</a>
<a  id=chooseall  >全选</a>
<a  id=unchooseall  >取消全选</a>
<a  id=btn_blue href="?g=update">更新实时热点</a>
</span>
<br><br>
</ul></div>
</body></html>

<?}?>



