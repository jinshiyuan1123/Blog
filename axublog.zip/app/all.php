﻿<?php

if (file_exists("../../cmsconfig.php"))  
    {require_once("../../cmsconfig.php");}  
    else{
    echo "<script language='javascript'>";
    echo "location='../../install/goinstall.php';";
    echo "</script>"; 
    } 


include_once("../../cmsconfig.php");
include_once("../../class/c_db.php");
include_once("../../class/c_other.php");
include_once("../../class/c_runtime.php");
include_once("../../class/c_page.php");
include_once("../../class/c_md5.php");
if(sqlguolv()==1){die('禁止输入特殊符号和非法访问！');}





global $codename,$codeversion,$codeurl,$cachepath;
$fromip=$_SERVER['REMOTE_ADDR'];
$www=$_SERVER["HTTP_HOST"];
if($fromip=='::1'&&$www='locahost'){$fromip='127.0.0.1';}
$file='../../'.$cachepath.$fromip.'.php';
#-------
function chkadcookie(){
		if(@$_SESSION["chkad"]==''||@$_SESSION["chkadtime1"]==''){
global $date,$cachepath,$fromip,$www,$file;
if(!file_exists($file)){header("Content-type:text/html; charset=utf-8");tiao();exit;}
$str=file_get_contents($file,'r');
$str=authcode($str, 'DECODE', 'key',0);
$result = array(); 
preg_match_all("/\[user\](.*)\[\/user\]/i",$str, $result); 
$txtuser=$result[1][0]; 
preg_match_all("/\[time\](.*)\[\/time\]/i",$str, $result); 
$txttime=$result[1][0]; 
preg_match_all("/\[ip\](.*)\[\/ip\]/i",$str, $result); 
$txtip=$result[1][0]; 
if($txtuser==''||$txtip==''||!is_numeric($txttime)){header("Content-type:text/html; charset=utf-8");tiao();exit;}
if($txtuser<>$_SERVER['HTTP_USER_AGENT']||$txtip<>$fromip||$txttime<time()){header("Content-type:text/html; charset=utf-8");tiao();exit;}
$_SESSION["chkadtime2"]=$txttime;
		}else{if(@$_SESSION["chkadtime2"]<time()){header("Content-type:text/html; charset=utf-8");tiao();exit;}}
}

function tiao(){
echo'请移步网站后台登录！';
}


?>