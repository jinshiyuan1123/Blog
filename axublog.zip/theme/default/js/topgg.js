﻿document.writeln("广告位");

