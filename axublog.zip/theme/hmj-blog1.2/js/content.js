﻿document.write(""); 



