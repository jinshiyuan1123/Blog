﻿document.write(""); 

