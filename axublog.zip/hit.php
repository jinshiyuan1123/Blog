<?php
header("Content-type:text/html; charset=utf-8");
require("cmsconfig.php");
require("class/c_other.php");
if(sqlguolv()==1){die('禁止输入特殊符号和非法访问！');}

$g=$_GET['g'];
if ($g=='arthit'){
$id=$_GET['id'];

if(!is_numeric($id)||$id<0){die('document.write("id err");');}
if(preg_match("/\"|\'|\./i",$_SERVER['QUERY_STRING'])==1){die('document.write("id err");');}

    if($id>0){
$tab=$tabhead."arts";
mysql_select_db($tab);
$sql=mysql_query("UPDATE ".$tab." SET hit=hit+1 where id=".$id);
$sql = mysql_query("select * from ".$tab." where id=".$id);
$row=mysql_fetch_array($sql);
    $str=$row['hit'];
    echo 'document.write('.$str.');';
    }
}



?>